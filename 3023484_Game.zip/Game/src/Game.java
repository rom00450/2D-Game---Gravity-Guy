import game2D.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


// Game demonstrates how we can override the GameCore class
// to create our own 'game'. We usually need to implement at
// least 'draw' and 'update' (not including any local event handling)
// to begin the process. You should also add code to the 'init'
// method that will initialise event handlers etc. 

// Student ID: 3023484


@SuppressWarnings("serial")


public class Game extends GameCore
{
	// Useful game constants
	static int screenWidth = 512;
	static int screenHeight = 384;
    int playerHealth = 100;

	// Game constants
    float 	lift = 0.005f;
    float	gravity = 0.0002f;
    float	fly = -0.04f;
    float	moveSpeed = 0.05f;
    
    // Game state flags
    boolean flap = false;
    boolean moveRight = false;
    boolean debug = false;
    boolean drawUpsideDown = false;
    boolean upsideDown = false;
    boolean playerPositionSet = false;
    boolean playerPositionSet2 = false;
    boolean powerUpCleared = false;
    private final Image bgImage = loadImage("images/1.png");
    private final Image bgImage2 = loadImage("images/6.png");
    private final Image bgImage3 = loadImage("images/2.png");
    private final Image bgImage4 = loadImage("images/3.png");
    private final Image bgImage5 = loadImage("images/4.png");
    private final Image nbg1 = loadImage("images/n1.png");
    private final Image nbg2 = loadImage("images/n2.png");
    private final Image nbg3 = loadImage("images/n3.png");
    private final Image nbg4 = loadImage("images/n4.png");
    private final Image nbg5 = loadImage("images/n5.png");
    private final Image introBackgroundImage = loadImage("images/gravity.jpg");
    private List<PowerUpSprite> powerUps = new ArrayList<PowerUpSprite>();
    private Sound soundTrack = new Sound("sounds/music_zapsplat_astro_race.wav");
    private Sound death = new Sound ("sounds/death.wav");
    private long introStartTime;
    private JButton restartButton;



    private GameState gameState = GameState.INTRO;
    public enum GameState {
        INTRO,
        LEVEL_1,
        LEVEL_2,
        GAME_OVER,
        WIN,
    }



    // Game resources
    Animation idle;
    Animation running;
    Animation eRunning;
    Animation speedPUAnimation;
    Animation deathPUAnimation;
    Animation nextLevelPUAnimation;
    Sprite player = null;
    EnemySprite enemy = null;

    PowerUpSprite speedPowerUp = null;
    PowerUpSprite deathPowerUp = null;
    PowerUpSprite nextLevelPowerUp = null;
    ArrayList<Sprite> 	clouds = new ArrayList<Sprite>();
    ArrayList<Tile>		collidedTiles = new ArrayList<Tile>();

    TileMap tmap = new TileMap();	// Our tile map, note that we load it in init()
    TileMap tmap2 = new TileMap();
    
    long total;         			// The score will be the total time elapsed since a crash


    /**
	 * The obligatory main method that creates
     * an instance of our class and starts it running
     * 
     * @param args	The list of parameters this program might use (ignored)
     */
    public static void main(String[] args) {

        Game gct = new Game();
        gct.init();
        // Start in windowed mode with the given screen height and width
        gct.run(false,screenWidth,screenHeight);
    }

    /**
     * Initialise the class, e.g. set up variables, load images,
     * create animations, register event handlers.
     * 
     * This shows you the general principles but you should create specific
     * methods for setting up your game that can be called again when you wish to 
     * restart the game (for example you may only want to load animations once
     * but you could reset the positions of sprites each time you restart the game).
     */
    public void init()
    {

        // Add mouse listener
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                handleMouseClick(e);
            }
        });

        introStartTime = System.currentTimeMillis(); // Set the intro start time

        Sprite s;	// Temporary reference to a sprite

        // Load the tile map and print it out so we can check it is valid
        tmap.loadMap("maps", "map.txt");
        tmap2.loadMap("maps","map2.txt");
        
        setSize(tmap.getPixelWidth()/8, tmap.getPixelHeight());
        setVisible(true);

        // Initialise restart button
        restartButton = new JButton("Restart");
        restartButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                remove(restartButton);
                playerPositionSet2 = false;
                gameState = GameState.LEVEL_1;
            }
        });

        // Create a set of background sprites that we can 
        // rearrange to give the illusion of motion
        
        idle = new Animation();
        idle.loadAnimationFromSheet("images/Cyborg_idle.png", 4, 1, 90);

        running = new Animation();
        running.loadAnimationFromSheet("images/Cyborg_run.png",6,1,90);

        eRunning = new Animation();
        eRunning.loadAnimationFromSheet("images/Punk_run.png",6,1,90);

        // Initialise the player with an animation
        player = new Sprite(idle);
        //Initialise enemy sprite with an animation
        enemy = new EnemySprite(eRunning, player, 0.09f);

        //creating powerups
        speedPUAnimation = new Animation();
        speedPUAnimation.loadAnimationFromSheet("images/money.png",6,1,90);


        deathPUAnimation = new Animation();
        deathPUAnimation.loadAnimationFromSheet("images/screen1.png",4,1,90);

        nextLevelPUAnimation = new Animation();
        nextLevelPUAnimation.loadAnimationFromSheet("images/card.png",8,1,90);

        // Load a single cloud animation
        Animation ca = new Animation();
        ca.addFrame(loadImage("images/cloud.png"), 1000);
        
        // Create 3 clouds at random positions off the screen
        // to the right
        for (int c=0; c<3; c++)
        {
        	s = new Sprite(ca);
        	s.setX(screenWidth + (int)(Math.random()*200.0f));
        	s.setY(30 + (int)(Math.random()*150.0f));
        	s.setVelocityX(-0.02f);
        	s.show();
        	clouds.add(s);
        }

        initialiseGame();
      		
        System.out.println(tmap);
    }

    /**
     * You will probably want to put code to restart a game in
     * a separate method so that you can call it when restarting
     * the game when the player loses.
     */
    public void initialiseGame()
    {
        soundTrack.start();

    	total = 0;
    	      
        player.setPosition(200,80);
        player.setVelocity(0,0);
        player.show();

        enemy.setPosition(10,80);
        enemy.show();


        PowerUpSprite speedPowerUp = new PowerUpSprite(speedPUAnimation, PowerUpSprite.PowerUpType.SPEED_BOOST);
        powerUps.add(speedPowerUp);
        speedPowerUp.setPosition(450, 130);
        speedPowerUp.show();

        PowerUpSprite speedPowerUp2 = new PowerUpSprite(speedPUAnimation, PowerUpSprite.PowerUpType.SPEED_BOOST);
        powerUps.add(speedPowerUp2);
        speedPowerUp2.setPosition(3320, 20);
        speedPowerUp2.show();


        PowerUpSprite deathPowerUp = new PowerUpSprite(deathPUAnimation, PowerUpSprite.PowerUpType.INSTANT_DEATH);
        powerUps.add(deathPowerUp);
        deathPowerUp.setPosition(1300, 145);
        deathPowerUp.show();

        PowerUpSprite deathPowerUp2 = new PowerUpSprite(deathPUAnimation, PowerUpSprite.PowerUpType.INSTANT_DEATH);
        powerUps.add(deathPowerUp2);
        deathPowerUp2.setPosition(2293, 120);
        deathPowerUp2.show();

        PowerUpSprite deathPowerUp3 = new PowerUpSprite(deathPUAnimation, PowerUpSprite.PowerUpType.INSTANT_DEATH);
        powerUps.add(deathPowerUp3);
        deathPowerUp3.setPosition(2820, 10);
        deathPowerUp3.show();

        PowerUpSprite nextLevelPowerUp = new PowerUpSprite(nextLevelPUAnimation, PowerUpSprite.PowerUpType.NEXT_LEVEL);
        powerUps.add(nextLevelPowerUp);
        nextLevelPowerUp.setPosition(4090,120);
        nextLevelPowerUp.show();
    }
    
    /**
     * Draw the current state of the game. Note the sample use of
     * debugging output that is drawn directly to the game screen.
     */


    public void draw(Graphics2D g){
        switch (gameState){
            case INTRO:
                drawIntroState(g);
                long elapsedTime = System.currentTimeMillis() - introStartTime;
                int INTRO_DURATION = 5000; // 5 seconds

                if (elapsedTime >= INTRO_DURATION) {
                    gameState = GameState.LEVEL_1;
                }
                break;
            case LEVEL_1:
                drawLevel1State(g);
                if(playerHealth == 0){
                    gameState = GameState.GAME_OVER;
                }
                break;
            case LEVEL_2:
                drawLevel2State(g);
                if(playerHealth == 0){
                    gameState = GameState.GAME_OVER;
                }
                break;
            case GAME_OVER:
                drawGameOverState(g);
                break;
            case WIN:
                drawWinState(g);
                break;
        }
    }

    private void drawIntroState(Graphics2D g){
        // Draw intro screen elements
        g.drawImage(introBackgroundImage, 0, 0, null);
        String msg = "Get Ready!";
        g.setFont(new Font("Arial", Font.BOLD, 12));
        g.setColor(Color.white);
        g.drawString(msg, 100, 120);
        g.setFont(new Font("Arial", Font.BOLD, 24));
        g.drawString("Gravity Game", 100, 100);
    }

    private void drawLevel1State(Graphics2D g){
// Be careful about the order in which you draw objects - you
        // should draw the background first, then work your way 'forward'

        g.setColor(Color.white);
        g.fillRect(0, 0, getWidth(), getHeight());

        // First work out how much we need to shift the view in order to
        // see where the player is. To do this, we adjust the offset so that
        // it is relative to the player's position along with a shift
        int xo = -(int)player.getX() + 200;
        int yo = -(int)player.getY() + 200;


        drawParallaxBackground(g, bgImage, xo, yo/2, 0.2f);
        drawParallaxBackground(g, bgImage2, xo, yo/2, 0.5f);
        drawParallaxBackground(g, bgImage3, xo, yo/2, 1.0f);
        // Apply offsets to sprites then draw them
        for (Sprite s: clouds)
        {
            s.setOffsets(xo,yo);
            s.draw(g);
        }
        drawParallaxBackground(g, bgImage4, xo, yo/2, 1.5f);
        drawParallaxBackground(g, bgImage5, xo, yo/2, 1.7f);

        // Apply offsets to tile map and draw  it
        tmap.draw(g,xo,yo);

        // Apply offsets to player and draw
        player.setOffsets(xo, yo);
        // Apply offsets to enemy and draw
        enemy.setOffsets(xo,yo);

        if(!drawUpsideDown){
            player.draw(g);
            enemy.draw(g);
        }
        else{
            player.setScale(1, -1);
            player.drawTransformed(g);
            enemy.setScale(1,-1);
            enemy.drawTransformed(g);
        }


        for (PowerUpSprite powerUp : powerUps) {
            powerUp.setOffsets(xo, yo);

            powerUp.draw(g);
        }

        // Show score and status information

        String msg = String.format("Level 1");
        g.setColor(Color.darkGray);
        g.drawString(msg, getWidth() - 100, 50);

        System.out.println(player.getX());
        System.out.println(player.getY());
        System.out.println("\n");

        if (debug)
        {
            // When in debug mode, you could draw borders around objects
            // and write messages to the screen with useful information.
            // Try to avoid printing to the console since it will produce
            // a lot of output and slow down your game.
            tmap.drawBorder(g, xo, yo, Color.black);

            g.setColor(Color.red);
            player.drawBoundingBox(g);
            enemy.drawBoundingBox(g);


            g.drawString(String.format("Player: %.0f,%.0f", player.getX(),player.getY()),
                    getWidth() - 150, 70);

            String healthDisplay = String.format("Health:" + playerHealth);
            g.drawString(healthDisplay, getWidth() - 150, 90);

            drawCollidedTiles(g, tmap, xo, yo);
        }
    }

    private void drawLevel2State(Graphics2D g){
        // Be careful about the order in which you draw objects - you
        // should draw the background first, then work your way 'forward'

        if (!powerUpCleared){
            powerUps.clear();
            powerUpCleared = true;
        }

        PowerUpSprite winningCard  = new PowerUpSprite(nextLevelPUAnimation, PowerUpSprite.PowerUpType.NEXT_LEVEL);
        powerUps.add(winningCard);
        winningCard.setPosition(4090,120);
        winningCard.show();


        g.setColor(Color.white);
        g.fillRect(0, 0, getWidth(), getHeight());

        // First work out how much we need to shift the view in order to
        // see where the player is. To do this, we adjust the offset so that
        // it is relative to the player's position along with a shift
        int xo = -(int)player.getX() + 200;
        int yo = -(int)player.getY() + 200;


        drawParallaxBackground(g, nbg1, xo, yo/2, 0.2f);
        drawParallaxBackground(g, nbg2, xo, yo/2, 0.5f);
        drawParallaxBackground(g, nbg3, xo, yo/2, 1.0f);
        // Apply offsets to sprites then draw them
        for (Sprite s: clouds)
        {
            s.setOffsets(xo,yo);
            s.draw(g);
        }
        drawParallaxBackground(g, nbg4, xo, yo/2, 1.5f);
        drawParallaxBackground(g, nbg5, xo, yo/2, 1.7f);

        // Apply offsets to tile map and draw  it
        tmap2.draw(g,xo,yo);

        // Apply offsets to player and draw
        player.setOffsets(xo, yo);
        // Apply offsets to enemy and draw
        enemy.setOffsets(xo,yo);

        if(!drawUpsideDown){
            player.draw(g);
            enemy.draw(g);
        }
        else{
            player.setScale(1, -1);
            player.drawTransformed(g);
            enemy.setScale(1,-1);
            enemy.drawTransformed(g);
        }


        for (PowerUpSprite powerUp : powerUps) {
            powerUp.setOffsets(xo, yo);

            powerUp.draw(g);
        }

        // Show score and status information
        String msg = String.format("Level 2");
        g.setColor(Color.darkGray);
        g.drawString(msg, getWidth() - 100, 50);

        if (debug)
        {
            // When in debug mode, you could draw borders around objects
            // and write messages to the screen with useful information.
            // Try to avoid printing to the console since it will produce
            // a lot of output and slow down your game.
            tmap2.drawBorder(g, xo, yo, Color.black);

            g.setColor(Color.red);
            player.drawBoundingBox(g);
            enemy.drawBoundingBox(g);


            g.drawString(String.format("Player: %.0f,%.0f", player.getX(),player.getY()),
                    getWidth() - 150, 70);

            String healthDisplay = String.format("Health:" + playerHealth);
            g.drawString(healthDisplay, getWidth() - 150, 90);

            drawCollidedTiles(g, tmap2, xo, yo);
        }
    }

    private void drawGameOverState(Graphics2D g){
        death.start();

        // Clear the canvas with a solid background color
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, getWidth(), getHeight());

        // Draw the "Game Over!" message
        g.setColor(Color.RED);
        g.setFont(new Font("Arial", Font.BOLD, 24));
        String gameOverMessage = "Game Over!";
        int messageX = (getWidth() - g.getFontMetrics().stringWidth(gameOverMessage)) / 2;
        int messageY = getHeight() / 2;
        g.drawString(gameOverMessage, messageX, messageY);

        // Drawing the restart button
        int buttonX = getWidth() / 2 - 75;
        int buttonY = messageY + 50;
        restartButton.setBounds(buttonX, buttonY, 150, 30);
        add(restartButton);
    }

    public void drawWinState(Graphics2D g) {
        // Clear the canvas with a solid background color
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, getWidth(), getHeight());

        // Draw the "Game Over!" message
        g.setColor(Color.GREEN);
        g.setFont(new Font("Arial", Font.BOLD, 24));
        String gameOverMessage = "YOU WIN!";
        int messageX = (getWidth() - g.getFontMetrics().stringWidth(gameOverMessage)) / 2;
        int messageY = getHeight() / 2;
        g.drawString(gameOverMessage, messageX, messageY);
    }

    public void drawParallaxBackground(Graphics2D g, Image image, int cameraX, int cameraY, float parallax)
    {
        int x = (int) (cameraX * parallax);
        int y = (int) (cameraY * parallax);
        int imageWidth = image.getWidth(null);

        // Calculate the number of repetitions needed to cover the screen
        int numRepetitions = 8;


        for (int i = 0; i <= numRepetitions; i++) {
            g.drawImage(image, x + i * imageWidth, y, null);
            g.drawImage(image, x + i * imageWidth - getWidth(), y, null);
        }
    }


    public void drawCollidedTiles(Graphics2D g, TileMap map, int xOffset, int yOffset)
    {
		if (collidedTiles.size() > 0)
		{	
			int tileWidth = map.getTileWidth();
			int tileHeight = map.getTileHeight();
			
			g.setColor(Color.blue);
			for (Tile t : collidedTiles)
			{
				g.drawRect(t.getXC()+xOffset, t.getYC()+yOffset, tileWidth, tileHeight);
			}
		}
    }
	
    /**
     * Update any sprites and check for collisions
     * 
     * @param elapsed The elapsed time between this call and the previous call of elapsed
     */    
    public void update(long elapsed)
    {
    	
        // Make adjustments to the speed of the sprite due to gravity
        player.setVelocityY(player.getVelocityY()+(gravity*elapsed));

       	player.setAnimationSpeed(1.0f);

       	if (flap)
       	{
       		player.setVelocityY(fly);
       	}

        if(upsideDown){
            gravity = -0.0002f;
        }
        else{
            gravity = 0.0002f;
        }
       	
       	if (moveRight) 
       	{
       		player.setVelocityX(moveSpeed*2);
       	}
       	else
       	{
       		player.setVelocityX(0);
       	}

        for (PowerUpSprite powerUp: powerUps)
            powerUp.update(elapsed);
       	
                
       	for (Sprite s: clouds)
       		s.update(elapsed);
       	
        // Now update the sprites animation and position
        if (gameState != GameState.INTRO) {
            player.update(elapsed);
            enemy.update(elapsed);
        }

       
        // Then check for any collisions that may have occurred
        if(gameState == GameState.LEVEL_1){
            if (playerPositionSet2 == false) {
                player.setPosition(200, 80);
                player.setVelocity(0, 0);
                enemy.setPosition(10, 80);
                playerPositionSet2 = true;
            }
            handleScreenEdge(player, tmap, elapsed);
        }
        else if(gameState == GameState.LEVEL_2){
            if (playerPositionSet == false) {
                player.setPosition(200, 80);
                player.setVelocity(0, 0);
                enemy.setPosition(10, 80);
                playerPositionSet = true;
            }
            handleScreenEdge(player,tmap2,elapsed);
        }

        if(gameState == GameState.LEVEL_1) {
            checkTileCollision(player, tmap);
        }
        else if(gameState == GameState.LEVEL_2){
            checkTileCollision(player, tmap2);
        }
        //checkTileCollision(enemy, tmap);

        if(boundingBoxCollision(player, enemy)){
            playerHealth = 0;
        }
    }

    
    
    /**
     * Checks and handles collisions with the edge of the screen. You should generally
     * use tile map collisions to prevent the player leaving the game area. This method
     * is only included as a temporary measure until you have properly developed your
     * tile maps.
     * 
     * @param s			The Sprite to check collisions for
     * @param tmap		The tile map to check 
     * @param elapsed	How much time has gone by since the last call
     */
    public void handleScreenEdge(Sprite s, TileMap tmap, long elapsed)
    {
        // Check if the sprite has gone off the bottom screen
        float bottomDifference = s.getY() + s.getHeight() - tmap.getPixelHeight();
        if (bottomDifference > 0) {
            // Decrease health and game over
            playerHealth = 0;
        }

        // Check if the sprite has gone off the top screen
        float topDifference = s.getY();
        if (topDifference < 0) {
            // Decrease health and game over
            playerHealth = 0;
        }
    }
    
    
     
    /**
     * Override of the keyPressed event defined in GameCore to catch our
     * own events
     * 
     *  @param e The event that has been generated
     */
    public void keyPressed(KeyEvent e) 
    { 
    	int key = e.getKeyCode();
    	
		switch (key)
		{
            //Only allows to flip gravity if the player is in contact with a tile. Prevents player from
            //flipping the character mid-air whenever they want
            case KeyEvent.VK_UP     : if(!collidedTiles.isEmpty()){
                                        flap = true;
                                        drawUpsideDown = true;
                                        upsideDown = true;
                                        handleMouseClick(new MouseEvent(this, MouseEvent.MOUSE_PRESSED, System.currentTimeMillis(), 0, getWidth() / 2, getHeight() / 4, 1, false, MouseEvent.BUTTON1)); // Simulate mouse click in the upper half of the screen
                                        break;
            }
            case KeyEvent.VK_DOWN   : if(!collidedTiles.isEmpty()){
                                        drawUpsideDown = false;
                                        upsideDown = false;
                                        handleMouseClick(new MouseEvent(this, MouseEvent.MOUSE_PRESSED, System.currentTimeMillis(), 0, getWidth() / 2, 3 * getHeight() / 4, 1, false, MouseEvent.BUTTON1)); // Simulate mouse click in the lower half of the screen
                                        break;
                                        }
			case KeyEvent.VK_RIGHT  : moveRight = true;
                                      player.setAnimation(running);
                                      break;
			case KeyEvent.VK_2 		: gameState = GameState.LEVEL_2;    //Switch to level 2 straight away
									  break;
			case KeyEvent.VK_ESCAPE : stop(); break;
			case KeyEvent.VK_B 		: debug = !debug; break; // Flip the debug state
			default :  break;
		}
    
    }

    /** Use the sample code in the lecture notes to properly detect
     * a bounding box collision between sprites s1 and s2.
     * 
     * @return	true if a collision may have occurred, false if it has not.
     */
    public boolean boundingBoxCollision(Sprite s1, Sprite s2)
    {
        Rectangle s1Box = new Rectangle((int)s1.getX(), (int) s1.getY(), s1.getWidth(), s1.getHeight());
        Rectangle s2Box = new Rectangle((int)s2.getX(), (int) s2.getY(), s2.getWidth()/2, s2.getHeight());
        //the division by two makes it detect when the bounding box of the enemy is halfway through the bounding
        //box of the player. ultimately detecting the collision when the images of the sprites are colliding
        return s1Box.intersects(s2Box);
    }
    
    /**
     * Check and handles collisions with a tile map for the
     * given sprite 's'. Initial functionality is limited...
     * 
     * @param s			The Sprite to check collisions for
     * @param tmap		The tile map to check 
     */

    public void checkTileCollision(Sprite s, TileMap tmap) {
        // Empty out our current set of collided tiles
        collidedTiles.clear();

        // Take a note of a sprite's current position
        float sx = s.getX();
        float sy = s.getY();

        // Find out how wide and how tall a tile is
        float tileWidth = tmap.getTileWidth();
        float tileHeight = tmap.getTileHeight();

        // Divide the sprite’s x coordinate by the width of a tile, to get
        // the number of tiles across the x axis that the sprite is positioned at
        int xtile = (int) (sx / tileWidth);
        // The same applies to the y coordinate
        int ytile = (int) (sy / tileHeight);

        // What tile character is at the top left of the sprite s?
        Tile tl = tmap.getTile(xtile, ytile);

        // Check for power-up collisions using an iterator
        Iterator<PowerUpSprite> iterator = powerUps.iterator();
        while (iterator.hasNext()) {
            PowerUpSprite powerUp = iterator.next();
            if (boundingBoxCollision(s, powerUp)) {
                switch (powerUp.getPowerUpType()) {
                    case SPEED_BOOST:
                        moveSpeed = moveSpeed*2;
                        iterator.remove(); // Safe removal using the iterator
                        break;
                    case INSTANT_DEATH:
                        playerHealth = 0;
                        break;
                    case NEXT_LEVEL:
                        if(gameState == GameState.LEVEL_1){
                            gameState = GameState.LEVEL_2;
                        }
                        else{
                            gameState = GameState.WIN;
                        }
                        break;

                }
            }
        }


    	
    	
    	if (tl != null && tl.getCharacter() != '.') // If it's not a dot (empty space), handle it
    	{
    		// Moves sprite to position that isn't colliding
            if (tl.getCharacter() != 'b' || tl.getCharacter() != 'x'){
                player.stop();
                player.setY((tl.getYC()+32));
                collidedTiles.add(tl);
            }
    	}

        // Check for tile collisions for the player sprite
        if (s == player) {
            handlePlayerTileCollision(tl, tmap, sx, sy, tileWidth, tileHeight);
        }
        // Check for tile collisions for the enemy sprite
        else if (s == enemy) {
            handleEnemyTileCollision(tl, tmap, sx, sy, tileWidth, tileHeight);
        }
    }

    private void handleMouseClick(MouseEvent e) {
        if (e.getButton() == MouseEvent.BUTTON1) { // Left mouse button
            if (!collidedTiles.isEmpty()) { // Check if the player is in contact with a tile
                if (e.getY() < getHeight() / 2) { // Click in the upper half of the screen
                    flap = true;
                    drawUpsideDown = true;
                    upsideDown = true;
                    gravity = -(gravity);
                } else { // Click in the lower half of the screen
                    gravity = 0.0002f;
                    flap = false;
                    drawUpsideDown = false;
                    upsideDown = false;
                }
            }
        }
    }

    private void handlePlayerTileCollision(Tile tl, TileMap tmap, float sx, float sy, float tileWidth, float tileHeight) {
        if (tl != null && tl.getCharacter() != '.') // If it's not a dot (empty space), handle it
        {
            // Moves sprite to position that isn't colliding
            if (tl.getCharacter() != 'b' || tl.getCharacter() != 'x') {
                player.stop();
                player.setY((tl.getYC() + 32));
                collidedTiles.add(tl);
            }
        }

        // We need to consider the other corners of the sprite
        // The above looked at the top left position, let's look at the bottom left.
        int xtile = (int) (sx / tileWidth);
        int ytile = (int) ((sy + player.getHeight()) / tileHeight);
        Tile bl = tmap.getTile(xtile, ytile);

        // If it's not empty space
        if (bl != null && bl.getCharacter() != '.') {
            //Moves sprite to position that isn't colliding
            player.stop();
            player.setY(bl.getYC() - 48);
            collidedTiles.add(bl);
        }

        // Check bottom right corner
        xtile = (int) ((sx + player.getWidth()) / tileWidth);
        ytile = (int) ((sy + player.getHeight()) / tileHeight);
        Tile br = tmap.getTile(xtile, ytile);
        // If it's not empty space
        if (br != null && br.getCharacter() != '.') {
            player.stop();
            collidedTiles.add(br);
        }

        // Check top right corner
        xtile = (int) ((sx + player.getWidth()) / tileWidth);
        ytile = (int) (sy / tileHeight);
        Tile tr = tmap.getTile(xtile, ytile);
        // If it's not empty space
        if (tr != null && tr.getCharacter() != '.') {
            player.stop();
            collidedTiles.add(tr);
        }
    }

    private void handleEnemyTileCollision(Tile tl, TileMap tmap, float sx, float sy, float tileWidth, float tileHeight) {
        if (tl != null && tl.getCharacter() != '.') // If it's not a dot (empty space), handle it
        {
            // Stop the enemy movement when colliding with a tile
            enemy.stop();
            collidedTiles.add(tl);
        }

        // We need to consider the other corners of the sprite
        // The above looked at the top left position, let's look at the bottom left.
        int xtile = (int) (sx / tileWidth);
        int ytile = (int) ((sy + enemy.getHeight()) / tileHeight);
        Tile bl = tmap.getTile(xtile, ytile);

        // If it's not empty space
        if (bl != null && bl.getCharacter() != '.') {
            //Stop the enemy movement when colliding with a tile
            enemy.stop();
            collidedTiles.add(bl);
        }

        // Check bottom right corner
        xtile = (int) ((sx + enemy.getWidth()) / tileWidth);
        ytile = (int) ((sy + enemy.getHeight()) / tileHeight);
        Tile br = tmap.getTile(xtile, ytile);
        // If it's not empty space
        if (br != null && br.getCharacter() != '.') {
            enemy.stop();
            collidedTiles.add(br);
        }

        // Check top right corner
        xtile = (int) ((sx + enemy.getWidth()) / tileWidth);
        ytile = (int) (sy / tileHeight);
        Tile tr = tmap.getTile(xtile, ytile);
        // If it's not empty space
        if (tr != null && tr.getCharacter() != '.') {
            enemy.stop();
            collidedTiles.add(tr);
        }
    }


	public void keyReleased(KeyEvent e) { 

		int key = e.getKeyCode();

		switch (key)
		{
			case KeyEvent.VK_ESCAPE : stop(); break;
			case KeyEvent.VK_UP     : flap = false; break;
			case KeyEvent.VK_RIGHT  : moveRight = false;
                                      player.setAnimation(idle);
                                      break;
			default :  break;
		}
	}
}
