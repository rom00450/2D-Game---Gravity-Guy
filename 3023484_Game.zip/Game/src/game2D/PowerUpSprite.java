package game2D;

import java.awt.*;

public class PowerUpSprite extends Sprite{

    public enum PowerUpType {
        SPEED_BOOST,
        INSTANT_DEATH,
        NEXT_LEVEL,
    }

    private PowerUpType powerUpType;

    public PowerUpSprite(Animation animation, PowerUpType type){
        super(animation);
        this.powerUpType = type;
    }
    public PowerUpType getPowerUpType(){
        return powerUpType;
    }
}
