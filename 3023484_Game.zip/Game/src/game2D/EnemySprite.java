package game2D;


public class EnemySprite extends Sprite {
    private Sprite playerSprite;
    private float speed; // The speed at which the enemy moves towards the player

    public EnemySprite(Animation animation, Sprite playerSprite, float speed) {
        super(animation);
        this.playerSprite = playerSprite;
        this.speed = speed;
    }

    @Override
    public void update(long elapsed) {
        super.update(elapsed);

        // Calculate the direction towards the player
        float dx = playerSprite.getX() - getX();
        float dy = playerSprite.getY() - getY();
        float distance = (float) Math.sqrt(dx * dx + dy * dy);

        if (distance > 0) {
            // Normalize the direction vector
            dx /= distance;
            dy /= distance;

            // Move the enemy towards the player
            setVelocityX(dx * speed);
            setVelocityY(dy);
        } else {
            // If the enemy is already at the player's position, stop moving
            stop();
        }
    }
}